# JobBoardApplication
Using React with GraphQL , apollo client and server
