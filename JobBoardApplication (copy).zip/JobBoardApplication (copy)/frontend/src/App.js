import React from 'react';

import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import GetAlljobs from './GetAlljobs'

import {isLoggedIn, logout} from './Auth'

import GetSinglejob from './GetSinglejob'

import CompanyDetails from './CompanyDetails';

import JobPost from './JobPost';

import Login from './Login';

import Header from './Header';


class App extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {loggedIn: isLoggedIn()};
  }
  handleLogin() {
    this.setState({loggedIn: true});
    this.router.history.push('/');
  }

  handleLogout(){
    logout();
    this.setState({loggedIn: false});
    this.router.history.push('/');
  }

  render(){
   const {loggedIn} = this.state;
   return (
    <Router ref={(router) => this.router = router}>
  
    <Header loggedIn={loggedIn} onLogout={this.handleLogout.bind(this)}/>
      <Switch>
    <Route path="/" exact component={GetAlljobs} />
    <Route path="/jobs/:jobId" component={GetSinglejob} />
    <Route path="/company/:companyId" component={CompanyDetails} />
    <Route exact path="/JobPost" component={JobPost} />    
    <Route exact path="/login" render={() => <Login onLogin={this.handleLogin.bind(this)} />} />   
    </Switch> 
    </Router>
  );  
}
}

export default App;
