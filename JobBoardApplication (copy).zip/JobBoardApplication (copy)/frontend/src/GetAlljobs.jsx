import React from 'react';

import { loadjobs } from './requests'

import ListofJobs from './ListofJobs'

import Header from './Header'

class GetAlljobs extends React.Component {

   constructor(props){
     super(props);
     this.state={jobs :[]};
   }

   async componentDidMount(){
    const jobs =  await loadjobs ();
    this.setState({jobs});
  }
  render() {
    const {jobs} = this.state;

    console.log("list jobs", jobs )
    return (
      <div>
   
    <ListofJobs jobs={jobs} />
    </div>
    )
  }

}
export default GetAlljobs