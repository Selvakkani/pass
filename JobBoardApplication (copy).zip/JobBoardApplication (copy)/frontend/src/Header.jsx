import React from 'react';
import { Link } from 'react-router-dom';

class Header extends React.Component {
    render(){
      const { loggedIn, onLogout } = this.props;
      if (loggedIn) {
    return(
       <div>
   <ul>
      <li> <Link to="/"> Home </Link> </li>
      <li><Link to="/JobPost"> Post job  </Link></li> 
      <li onClick={onLogout}> Logout  </li> 

   </ul>
   </div>
    );
   }
   else{
      return(
      <div>
      <ul>
      <li> <Link to="/"> Home </Link> </li>
      <li><Link to="/login">login </Link></li>
   </ul>
   </div>
   )
   }

   

    }
   }
 export default Header