import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class ListofJobs extends React.Component {

  render() {
    
    const jobs = this.props.jobs;
        
    const carNode = jobs.map((job) => {
        return (
         <ul><li> 
          <Link
                to={"/jobs/"+job.id}
                className="list-group-item"
                key={job.id}>
                {job.title}
            </Link>
            </li></ul>
        )
    });
    return (
        <div>
            <h1>Jobs</h1>
            <div className="list-group">
            {carNode}
            </div>
        </div>
    );
  }
}
export default ListofJobs