import React from 'react';
import { ApolloConsumer } from 'react-apollo';
import {withRouter} from 'react-router-dom';



const handleSignOut = (client,history) =>{
    localStorage.setItem('token','');
    client.clearStore().then(() => {
        client.resetStore();
        history.push('/'); // redirect user to login page
      });
}


const Signout = ({history}) =>(
    <ApolloConsumer>
    {client =>{
        console.log(client);
        return <button onClick={() => handleSignOut(client,history)}>Signout</button>
    }}
    </ApolloConsumer>
);

export default withRouter(Signout);