import React from 'react';
import {withRouter} from 'react-router-dom';
import {Query} from 'react-apollo';
import {GET_RECIPE} from '../../queries/index';


const RecipePage = ({ match}) =>{
   const { _id } = match.params;
   console.log(_id);
return(
 <Query query={GET_RECIPE} variables={{_id}}>
{({data,loading,error}) =>{
    if(loading) return <div>loading </div>;
    if(error) return <div>Error</div>;
    console.log(data);
    return(<div className="App">

    <div className="recipe-background-image"
      style={{ background:`url(${data.getRecipe.imageUrl}) center center / cover no-repeat` }}>
    </div>

    <div className="recipe">
        <div className="recipe-header">
            <h2 className="recipe-name">
                <strong> {data.getRecipe.name} </strong>
            </h2>
            <h5>
               <strong>{data.getRecipe.category}</strong>
            </h5>
            <p> Created By: <strong>{data.getRecipe.username} </strong></p>
        </div>
            <blockquote className="recipe-description">
                {data.getRecipe.description}
            </blockquote>
            <h3 className="recipe-instructions__title">Instructions</h3>
            <div className="recipe-instructions">
            {data.getRecipe.instructions}
            </div>
    </div>
</div>);

}}
 </Query>
);
}

export default withRouter(RecipePage);