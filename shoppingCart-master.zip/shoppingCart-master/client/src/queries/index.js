import {gql} from 'apollo-boost';
import Search from '../components/Recipe/Search';

// Recipes Queries
export const GET_ALL_RECIPES =gql`
    query{
        getAllRecipes{
            _id
            name
            category
            likes
            imageUrl
        }
    }
`;

export const GET_RECIPE=gql`
    query($_id : ID!){
        getRecipe(_id :$_id ){
            _id
            name
            category
            description
            instructions
            createdDate
            likes
            username 
            imageUrl
    
  }
}
`;

export const SEARCH_RECIPES=gql`
query ($searchTerm : String){
    searchRecipes(searchTerm: $searchTerm){
        _id
        name
        likes

    }
}
`;






// Recipes Mutation

export const ADD_RECIPE =gql`
mutation($name:String!,$imageUrl:String!,$category: String!, $description: String!,$instructions: String!,$username:String){
    addRecipe(name:$name,imageUrl:$imageUrl,category:$category,instructions:$instructions,description:$description,username:$username){
        _id
            name
            category
            description
            instructions
            createdDate
            likes
            username
            imageUrl
           }
}

`;



//User Queries

export const GET_CURRENT_USER =gql`
    query{
        getCurrentUser{
            username
            joinDate
            email
            favorites{
                _id
                name
            }
        }
    }
`;


//User Mutation

export const SIGNIN_USER=gql`
    mutation($username:String!,$password: String!){
        signinUser(username:$username,password:$password){
            token
  }
}
`;

export const SIGNUP_USER=gql`
    mutation($username: String! ,$email: String!,$password : String!) {
        signupUser(username: $username,email:$email,password:$password){
            token
        }
    }
`;